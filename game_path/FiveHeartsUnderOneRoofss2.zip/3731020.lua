-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3731020)
addappid(3731021,0,"6c8a7201c4ca604359838797d37767cef71d5a105fa1c69bd3049c2320646947")
addappid(4054090,0,"a8181a87732e029df7a081f3c88557a7ff70410aa33046867eb281dc34604c48")
